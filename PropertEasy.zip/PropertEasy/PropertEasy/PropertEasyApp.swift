//
//  PropertEasyApp.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI
@main
struct PropertEasyApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                MainTabView()
            }
        }
    }
}

//
//  LoginView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct LoginView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Log In")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Button("Continue with Phone") {
                // Action
            }
            .buttonStyle(AuthButtonStyle())
            
            Button("Continue with Email") {
                // Action
            }
            .buttonStyle(AuthButtonStyle())
            
            Button("Continue with Apple") {
                // Action
            }
            .buttonStyle(AuthButtonStyle())
            
            Button("Continue with Google") {
                // Action
            }
            .buttonStyle(AuthButtonStyle())
            
            Button("Continue with Facebook") {
                // Action
            }
            .buttonStyle(AuthButtonStyle())
            
            Spacer()
            
            Button("Continue as Guest") {
                // Action
            }
            .foregroundColor(.blue)
        }
        .padding()
    }
}

struct AuthButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.blue.opacity(configuration.isPressed ? 0.7 : 1))
            .foregroundColor(.white)
            .cornerRadius(8)
    }
}

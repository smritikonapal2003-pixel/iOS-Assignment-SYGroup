//
//  SignupView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct SignupView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Sign Up")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            // Similar buttons as LoginView or custom signup form
            
            Spacer()
        }
        .padding()
    }
}

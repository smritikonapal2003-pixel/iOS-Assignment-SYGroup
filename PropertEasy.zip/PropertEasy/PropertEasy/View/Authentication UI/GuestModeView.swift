//
//  GuestModeView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct GuestModeView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Guest Mode")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text("Limited access. Please log in or sign up for full features.")
                .multilineTextAlignment(.center)
                .padding()
            
            Button("Log In / Sign Up") {
                // Navigate to login/signup
            }
            .buttonStyle(AuthButtonStyle())
            
            Spacer()
        }
        .padding()
    }
}

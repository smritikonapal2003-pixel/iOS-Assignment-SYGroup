//
//  ProfileActionButtons.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct ProfileActionButtons: View {
    let title: String
    let icon: String
    let color: Color
    
    @State private var animate = false
    
    var body: some View {
        Button(action: {
            // Action placeholder
        }) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.white)
                    .padding(8)
                    .background(color)
                    .clipShape(Circle())
                    .scaleEffect(animate ? 1.1 : 1.0)
                    .animation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true), value: animate)
                    .onAppear {
                        animate = true
                    }
                
                Text(title)
                    .foregroundColor(.primary)
                    .fontWeight(.semibold)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(10)
        }
    }
}

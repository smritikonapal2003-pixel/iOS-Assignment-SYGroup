//
//  MainTabView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//


import SwiftUI

struct MainTabView: View {
    @State private var selectedTab: Tab = .explore
    
    enum Tab {
        case explore, wishlists, listing, messages, profile
    }
    
    var body: some View {
        TabView(selection: $selectedTab) {
            ExploreView()
                .tabItem {
                    Label("Explore", systemImage: "magnifyingglass")
                }
                .tag(Tab.explore)
            
            WishlistsView()
                .tabItem {
                    Label("Wishlists", systemImage: "heart")
                }
                .tag(Tab.wishlists)
            
            ListingView()
                .tabItem {
                    Label("Listing", systemImage: "house")
                }
                .tag(Tab.listing)
            
            MessagesView()
                .tabItem {
                    Label("Messages", systemImage: "message")
                }
                .tag(Tab.messages)
            
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle")
                }
                .tag(Tab.profile)
        }
    }
}

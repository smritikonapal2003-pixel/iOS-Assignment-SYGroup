//
//  ProfileView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                ProfileHeaderView()
                
                VStack(spacing: 16) {
                    ProfileActionButtons(title: "Become a Professional", icon: "star.fill", color: .yellow)
                    ProfileActionButtons(title: "Business Collaboration / Franchise", icon: "briefcase.fill", color: .green)
                }
                
                Spacer()
            }
            .padding()
            .navigationTitle("Profile")
        }
    }
}

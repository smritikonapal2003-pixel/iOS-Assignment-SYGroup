//
//  PropertyCardView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//


import SwiftUI

struct PropertyCardView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 160, height: 100)
                .cornerRadius(10)
                .overlay(
                    Text("Image")
                        .foregroundColor(.white)
                )
            
            Text("Property Title")
                .font(.subheadline)
                .fontWeight(.semibold)
                .lineLimit(1)
            
            Text("Location")
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .frame(width: 160)
    }
}

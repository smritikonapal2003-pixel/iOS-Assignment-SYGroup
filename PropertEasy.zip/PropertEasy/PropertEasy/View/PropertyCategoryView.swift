//
//  PropertyCategoryView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct PropertyCategoryView: View {
    let title: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
                .padding(.bottom, 8)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 16) {
                    ForEach(0..<5) { index in
                        PropertyCardView()
                    }
                }
            }
        }
    }
}

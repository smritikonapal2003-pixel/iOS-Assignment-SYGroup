//
//  QuickAccessButtons.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct QuickAccessButtons: View {
    var body: some View {
        HStack(spacing: 24) {
            QuickAccessButton(icon: "house.fill", label: "Real Estate")
            QuickAccessButton(icon: "person.2.fill", label: "Professionals")
            QuickAccessButton(icon: "wrench.fill", label: "Services")
        }
    }
}

struct QuickAccessButton: View {
    let icon: String
    let label: String

    @State private var animate = false

    var body: some View {
        VStack {
            Image(systemName: icon)
                .font(.system(size: 28))
                .foregroundColor(.white)
                .padding()
                .background(Color.blue)
                .clipShape(Circle())
                .scaleEffect(animate ? 1.1 : 1.0)
                .animation(Animation.easeInOut(duration: 1).repeatForever(autoreverses: true), value: animate)
                .onAppear {
                    animate = true
                }

            Text(label)
                .font(.footnote)
                .foregroundColor(.primary)
        }
    }
}


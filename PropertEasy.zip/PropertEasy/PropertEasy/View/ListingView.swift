//
//  ListingView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct ListingView: View {
    var body: some View {
        Text("Listing Screen")
            .font(.title)
            .foregroundColor(.gray)
    }
}

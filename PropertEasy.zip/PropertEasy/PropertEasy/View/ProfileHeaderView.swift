//
//  ProfileHeaderView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct ProfileHeaderView: View {
    var body: some View {
        HStack(spacing: 16) {
            Circle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 80, height: 80)
                .overlay(Text("Img").foregroundColor(.white))
            
            VStack(alignment: .leading) {
                Text("Smriti Pal")
                    .font(.title2)
                    .fontWeight(.bold)
                Text("smriti.pal@example.com")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            Spacer()
        }
    }
}

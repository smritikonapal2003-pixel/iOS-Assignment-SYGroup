//
//  ExploreView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct ExploreView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                SearchBarView()
                    .padding(.horizontal)
                
                QuickAccessButtons()
                    .padding(.horizontal)
                
                ScrollView {
                    VStack(spacing: 24) {
                        PropertyCategoryView(title: "Real Estate")
                        PropertyCategoryView(title: "Professionals")
                        PropertyCategoryView(title: "Services")
                    }
                    .padding(.horizontal)
                }
            }
            .navigationTitle("Explore")
        }
    }
}

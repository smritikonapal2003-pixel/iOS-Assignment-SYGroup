//
//  WishlistsView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct WishlistsView: View {
    var body: some View {
        Text("Wishlists Screen")
            .font(.title)
            .foregroundColor(.gray)
    }
}

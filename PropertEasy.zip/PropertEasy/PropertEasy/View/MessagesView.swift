//
//  MessagesView.swift
//  PropertEasy
//
//  Created by Subrata Kundu on 20/09/25.
//

import SwiftUI

struct MessagesView: View {
    var body: some View {
        Text("Messages Screen")
            .font(.title)
            .foregroundColor(.gray)
    }
}
